/* heading.h */

#define YY_NO_UNPUT

using namespace std;

#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <string>

