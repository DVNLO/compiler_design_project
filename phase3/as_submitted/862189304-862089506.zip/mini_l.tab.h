/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_MINI_L_TAB_H_INCLUDED
# define YY_YY_MINI_L_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 7 "mini_l.y" /* yacc.c:1909  */

#include "errors.h"
#include "instructions.h"
#include "semantics.h"
#include "types.h"
#include <iostream>

#line 52 "mini_l.tab.h" /* yacc.c:1909  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    IDENT = 258,
    NUMBER = 259,
    ASSIGN = 260,
    OR = 261,
    AND = 262,
    NOT = 263,
    LT = 264,
    LTE = 265,
    GT = 266,
    GTE = 267,
    EQ = 268,
    NEQ = 269,
    ADD = 270,
    SUB = 271,
    MULT = 272,
    DIV = 273,
    MOD = 274,
    L_SQUARE_BRACKET = 275,
    R_SQUARE_BRACKET = 276,
    FUNCTION = 277,
    BEGIN_PARAMS = 278,
    END_PARAMS = 279,
    BEGIN_LOCALS = 280,
    END_LOCALS = 281,
    BEGIN_BODY = 282,
    END_BODY = 283,
    INTEGER = 284,
    ARRAY = 285,
    OF = 286,
    IF = 287,
    THEN = 288,
    ENDIF = 289,
    ELSE = 290,
    WHILE = 291,
    DO = 292,
    FOR = 293,
    BEGINLOOP = 294,
    ENDLOOP = 295,
    CONTINUE = 296,
    READ = 297,
    WRITE = 298,
    TRUE = 299,
    FALSE = 300,
    RETURN = 301,
    SEMICOLON = 302,
    COLON = 303,
    COMMA = 304,
    L_PAREN = 305,
    R_PAREN = 306
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 16 "mini_l.y" /* yacc.c:1909  */

  std::string * op_val;
  identifier_t * id_nt_val;
  identifiers_t * ids_nt_val;
  number_t * num_nt_val;
  variable_t * var_nt_val;
  variables_t * vars_nt_val;
  expression_t * exp_nt_val;
  comparison_t * comp_nt_val;
  statement_t * statement_nt_val; 
  declaration_t * decl_nt_val;
  declarations_t * decls_nt_val;
  parameters_t * params_nt_val;
  locals_t * locals_nt_val;
  parameter_list_t * param_list_nt_val;
  function_t * function_nt_val;
  functions_t * functions_nt_val;

#line 135 "mini_l.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_MINI_L_TAB_H_INCLUDED  */
